__author__ = 'kdao'
import sys



sys.path.append("Users/kdao/PycharmProjects/Tutor")


import pytz
#
utc = pytz.utc
print sys.path